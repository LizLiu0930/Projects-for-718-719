package diseasesinfo;

public class NonInfectiousDisease implements InfectiousStatus{
    private String notInfectious;


    @Override
    public String getStatus() {
        return notInfectious;
    }
}
