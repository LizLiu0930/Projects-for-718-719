package diseasesinfo;

public class HepatitisB extends Disease implements TransmissionPath{

    //TODO: 5a. Implements diseases.TransmissionPath interface and include the necessary method.

    public HepatitisB( int curePercentage) {
        super("Hepatitis B", 1965, "yellowing of the eyes, abdominal pain and dark urine", curePercentage);
        this.infectiousStatus = new InfectiousDisease();
    }

    @Override
    public String getPath() {
        return "blood";
    }

    //TODO: 5b. Create getVaccineProtectionDuration() method
    public int getVaccineProtectionDuration(){
        return 30;
    }
}
