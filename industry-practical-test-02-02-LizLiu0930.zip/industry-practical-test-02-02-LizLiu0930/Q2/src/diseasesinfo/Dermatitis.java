package diseasesinfo;

public class Dermatitis extends Disease{

    private int curePercentage;

    public Dermatitis(int curePercentage, int curePercentage1) {
        super("Dermatitis(eczema)", 1572, "itchy,dryskin,arashonswollen,reddenedskin", curePercentage);
        this.curePercentage = curePercentage1;
    }


}
