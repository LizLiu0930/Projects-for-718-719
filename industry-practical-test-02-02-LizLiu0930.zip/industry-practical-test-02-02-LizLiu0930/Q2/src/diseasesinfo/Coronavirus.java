package diseasesinfo;

public class Coronavirus extends Disease implements TransmissionPath{
    private String name;
    private String symptoms;
    private int discoveryYear;
    private int curePercentage;

    public Coronavirus(String name, int discoveryYear, String symptoms, int curePercentage) {
        super(name, discoveryYear, symptoms, curePercentage);
    }

    public int getVaccineProtectionDuration() {
        return 1;
    }
}
