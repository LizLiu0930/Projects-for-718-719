package diseasesinfo;

public interface InfectiousStatus {
    String getStatus();
}
