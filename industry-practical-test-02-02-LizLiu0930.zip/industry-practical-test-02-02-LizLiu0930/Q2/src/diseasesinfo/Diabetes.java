package diseasesinfo;

public class Diabetes extends Disease {

    //TODO: 6a. Declare an int field with 'type' as the variable name
    private int type;


    public Diabetes(String name, int discoveryYear, String symptoms, int curePercentage) {
        super(name, discoveryYear, symptoms, curePercentage);
        this.infectiousStatus = new NonInfectiousDisease();
    }


    //TODO: 6b. Create the getter and setter methods for type variable


    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}
