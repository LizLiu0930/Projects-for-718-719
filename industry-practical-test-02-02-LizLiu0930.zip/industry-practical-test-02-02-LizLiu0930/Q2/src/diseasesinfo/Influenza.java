package diseasesinfo;

public class Influenza extends Disease implements TransmissionPath{

    public Influenza(int curePercentage) {
        super("Influenza(flu)", 1357, "fever,chills,muscleaches,cough,congestion,runny nose,headachesandfatigue", curePercentage);
    }


    @Override
    public String getPath() {
        return "droplet";
    }

    public int getVaccineProtectionDuration() {
        return 1;
    }
}
