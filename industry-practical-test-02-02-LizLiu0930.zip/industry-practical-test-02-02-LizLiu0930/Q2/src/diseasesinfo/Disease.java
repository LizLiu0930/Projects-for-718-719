package diseasesinfo;

public abstract class Disease {

    protected String name, symptoms;
    protected int discoveryYear, curePercentage;
    protected InfectiousStatus infectiousStatus;

    public Disease(String name, int discoveryYear, String symptoms, int curePercentage) {
        this.name = name;
        this.discoveryYear = discoveryYear;
        this.symptoms = symptoms;
        this.curePercentage = curePercentage;

    }

    public String getName() {
        return name;
    }

    public int getCurePercentage() {
        return curePercentage;
    }

    public void setCurePercentage(int curePercentage) {
        this.curePercentage = curePercentage;
    }

    public String generateDiseaseInformation() {
        return name + " [" + discoveryYear + "]: " + symptoms;
    }

    public InfectiousStatus getInfectiousStatus() {
        return infectiousStatus;
    }

    public void displayInfectiousStatus() {
        System.out.println(name + " is " + infectiousStatus.getStatus() + ".");
    }

}
