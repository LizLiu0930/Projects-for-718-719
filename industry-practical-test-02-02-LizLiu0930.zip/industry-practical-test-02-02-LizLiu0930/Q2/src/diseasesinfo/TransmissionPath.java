package diseasesinfo;

public interface TransmissionPath {
    String getPath();
}
