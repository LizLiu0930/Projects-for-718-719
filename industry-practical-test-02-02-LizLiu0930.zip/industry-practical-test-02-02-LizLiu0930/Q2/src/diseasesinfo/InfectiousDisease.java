package diseasesinfo;

public class InfectiousDisease implements InfectiousStatus{
    private String infectious;

    InfectiousStatus[] nonInfectiousDisease = new InfectiousStatus[];


    @Override
    public String getStatus() {
        return infectious;
    }
}
