import diseasesinfo.*;

public class DiseaseKnowledgeApp {

    private void start() {

        //TODO: 7b. Initialise diseases array and fill in the last three elements.
        DiseaseKnowledgeApp[] diseases = new DiseaseKnowledgeApp[5];

        diseases[0] = new HepatitisB(generateCurePercentage());
        diseases[1] = new Diabetes("diseases.Diabetes", 1889,"thirst, frequent urination, hunger, fatigue and blurred vision", generateCurePercentage());
        diseases[2] = new Dermatitis(generateCurePercentage());
        diseases[3] = new Influenza(generateCurePercentage());
        diseases[4] = new Coronavirus(generateCurePercentage());


        System.out.println();
        System.out.println("Display diseases information");
        System.out.println("============================");
        //TODO: 7c. Appropriately call the printDiseasesInformation() method
        printDiseasesInformation(DiseaseKnowledgeApp[] diseases);

        System.out.println("============================");

        System.out.println();
        System.out.println("Display disease cure rate");
        System.out.println("-------------------------");
        //TODO: 7d. Appropriately call the printDiseaseCureRate() method
        printDiseaseCureRate(DiseaseKnowledgeApp[] diseases);

        System.out.println("-------------------------");

        System.out.println();
        System.out.println("Display infectious diseases transmission path");
        System.out.println("=============================================");
        //TODO: 7e. Appropriately call the printInfectiousDiseases() method
        printInfectiousDiseases(DiseaseKnowledgeApp[] diseases);

        System.out.println("=============================================");

        System.out.println();
        System.out.println("Display disease cure rate after the new science break-through");
        System.out.println("-------------------------------------------------------------");
        //TODO: 7d. Appropriately call the printDiseaseCureRate() method
        printDiseaseCureRate(DiseaseKnowledgeApp[] diseases);


        System.out.println("-------------------------------------------------------------");
        System.out.println();

        //TODO: 7f. set the diabetes type to 2 and print the result


    }

    //TODO: 7a.Create the generateCurePercentage() method
    public int generateCurePercentage(){
        int number = (int)(Math.random() * 60) + 20;
        return number;
    }


    //TODO: 7c. Create the printDiseasesInformation() method
    public void printDiseasesInformation(DiseaseKnowledgeApp[] diseases) {
        for (int i = 0; i < diseases.length; i++) {
            System.out.println(generateDiseaseInformation() + ". " + diseases[i].getName()
                    + " is " + diseases[i].getInfectiousStatus());
        }

    }


    //TODO: 7d. Create the printDiseaseCureRate() method
    public void printDiseaseCureRate(DiseaseKnowledgeApp[] diseases) {
        for (int i = 0; i < diseases.length; i++) {
            System.out.println(diseases[i].getName() + " cure rate is " + diseases[i].getCurePercentage() + "%");
        }
    }


    //TODO: 7e. Create the printInfectiousDiseases() method
    public void printInfectiousDiseases(DiseaseKnowledgeApp[] diseases){
        System.out.println(diseases[i].getInfectiousStatus());
    }


    public static void main(String[] args) {
        DiseaseKnowledgeApp app = new DiseaseKnowledgeApp();
        app.start();
    }
}
