package weatherreport;

public class WeatherReportGenerator {


    private void start() {
        //TODO: 2. Declare and construct an array of City objects. The array variable name musts be 'cities'.

        City[] cities  = generateCitiesyWeather();

        System.out.println();
        System.out.println("New Zealand City Weather Report");
        System.out.println("===============================");
        printCitiesWeather(cities);
        System.out.println("===============================");
        System.out.println();

        City hottestCity = getHottestCity(cities);
        System.out.println("The hottest city in New Zealand is " + hottestCity);
        int numOfSunnyCities = countCitiesWithCriteria(cities, "sunny", 50);
        int numOfShowerCities = countCitiesWithCriteria(cities, "showers", 80);
        System.out.println("There are " + numOfSunnyCities + " sunny cities in New Zealand.");
        System.out.println("There are " + numOfShowerCities + " cities with showers in New Zealand.");
        System.out.println();

        int averageWindSpeed = getAverageWindSpeed(cities);
        System.out.println("The cities with the wind speed +/-2km/hr of the average wind speed");
        System.out.println("------------------------------------------------------------------");
        printCitiesBetweenWindRange(cities,averageWindSpeed-2, averageWindSpeed+2);

    }

    //TODO: 3. Complete the printCitiesWeather() method
    private void printCitiesWeather(City[] cities) {
        for (int i = 0; i < cities.length; i++) {
            System.out.println(cities[i].toString() + ", Humidity " + cities[i].getHumidity() + "%");
        }

    }

    //TODO: 4. Complete the getHottestCity() method
    private City getHottestCity(City[] cities) {
        City hottestCity = cities[0];
        for (int i = 0; i < cities.length; i++) {
            if (cities[i].isHotterThan(hottestCity)) {
                hottestCity = cities[i];
            }
        }
        return hottestCity;
    }

    //TODO: 5. Complete the countCitiesWithCriteria() method
    private int countCitiesWithCriteria(City[] cities, String condition, int humidity) {
        int number = 0;
        String cityLowerCase = ("" + condition).toLowerCase();
        for (int i = 0; i < cities.length; i++) {
            String cityDescription = ("" + cities[i].getDescription().toLowerCase());
            int cityHuminity = cities[i].getHumidity();
            boolean citiesWithCondition = cityDescription.indexOf(cityLowerCase) >= 0;

            if (cityHuminity <= humidity && citiesWithCondition) {
                number++;
            }
        }
            return number;

    }

    //TODO: 6. Complete the getAverageWindSpeed() method
    private int getAverageWindSpeed(City[] cities) {
        int sumOfWind = 0;
        int averageWindSpeed = sumOfWind / cities.length;
        for (int i = 0; i < cities.length; i++) {
            sumOfWind += cities[i].getWindSpeed();
        }
        return averageWindSpeed;
    }

    //TODO: 7. Complete the printCitiesBetweenWindRange() method
    private void printCitiesBetweenWindRange(City[] cities, int lowerBound, int upperBound) {
        int averageWindSpeed = getAverageWindSpeed(cities);
        for (int i = 0; i < cities.length; i++) {
            int windBound = cities[i].getWindSpeed();
            if ( lowerBound <= windBound + 2 && windBound >= upperBound - 2) {
                System.out.println(cities[i].toString());
            }
        }

    }

    private City[] generateCitiesyWeather(){
        City[] cities = new City[12];
        cities[0] = new City("Whangarei", "Thunderstorms, strong winds", 11, 19, 25 , 89);
        cities[1] = new City("Auckland", "Sunny, light winds", 11, 20, 15, 50);
        cities[2] = new City("Hamilton", "Raining, light winds", 9, 19, 6, 90);
        cities[3] = new City("Rotorua", "Sunny, moderate winds", 6, 15, 18, 40);
        cities[4] = new City("Taupo", "Sunny, strong winds", 4, 14, 25, 45);
        cities[5] = new City("Napier", "Fine, light winds", 5, 19, 6, 30);
        cities[6] = new City("Palmerston North", "Heavy rain, moderate winds", 5, 13, 16, 100);
        cities[7] = new City("Wellington", "Showers, moderate winds", 10, 16, 16, 75);
        cities[8] = new City("Christchurch", "Cloudy, strong winds", 6, 13, 27, 70);
        cities[9] = new City("Queenstown", "Sunny, light winds", 1, 14, 7, 75);
        cities[10] = new City("Dunedin", "Showers, moderate winds", 8, 13, 13, 68);
        cities[11] = new City("Invercargill", "Showers, Strong winds", 2, 13, 23, 90);
        return cities;
    }

    public static void main(String[] args) {
        WeatherReportGenerator reportGenerator = new WeatherReportGenerator();
        reportGenerator.start();
    }

}
