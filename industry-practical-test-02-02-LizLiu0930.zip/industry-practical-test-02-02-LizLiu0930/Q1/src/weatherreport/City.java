package weatherreport;

public class City {

    private String name;
    private String description;
    private int lowTemp;
    private int highTemp;
    private int windSpeed;
    private int humidity;

    public City(String name, String description, int lowTemp, int highTemp, int windSpeed, int humidity){
        this.name = name;
        this.description = description;
        this.lowTemp = lowTemp;
        this.highTemp = highTemp;
        this.windSpeed = windSpeed;
        this.humidity = humidity;
    }

    // TODO: 1. Create the toString() method.
//    Whangarei: (11 - 19)C, Thunderstorms, strong winds, Wind 25km/hr, Humidity 89%
    public String toString() {
        return name + ": (" + lowTemp + " - " + highTemp + ")C, "
                + description + ", Wind " + windSpeed + "km/hr";
    }


    public String getName() {
        return name;
    }

    public String getDescription(){
        return description;
    }

    public int getLowTemp() {
        return lowTemp;
    }

    public int getHighTemp() {
        return highTemp;
    }

    public int getWindSpeed() {
        return windSpeed;
    }

    public int getHumidity() {
        return humidity;
    }

    public boolean isHotterThan(City other){
        if(other.highTemp > this.highTemp){
            return false;
        }
        return true;
    }
}
